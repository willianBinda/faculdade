#include <bits/stdc++.h>
#include <unistd.h>
int main(){
	int valor=0, cp=0, ci=0;
	while(valor<=0){
		printf("Digite um valor maior que 0\n");
		scanf("%d",&valor);
	}
	while(valor>0){
		if(valor & 1<<0){
			ci++;
			printf("%d impar\n", valor);
		} else {
			cp++;
			printf("%d par\n", valor);
		}
		valor--;
	}
	printf("\n%d Pares\n%d Impares\n", cp, ci);
}