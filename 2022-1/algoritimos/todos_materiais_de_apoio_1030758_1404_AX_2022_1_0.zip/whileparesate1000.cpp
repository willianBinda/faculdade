#include <bits/stdc++.h>
#include <unistd.h>
int main () {
    long long int x=1000;
    while(x>=0){
    	if(!(x & (1<<(0)))){
    	//if(x%2 == 0){
        printf("%d\n",x);
        //usleep(100);
      }
      x--;
    }
    printf("valor após while %d\n", x);
}