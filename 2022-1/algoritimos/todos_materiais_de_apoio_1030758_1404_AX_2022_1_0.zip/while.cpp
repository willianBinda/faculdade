#include <bits/stdc++.h>
#include <unistd.h>
int main(){
	int x=65, y=97;
	char ch = 'a', ch1='a';
	if(ch == ch1){
		printf("iguais");	
	}
	double soma=0, a = 0.565217391;
	printf("%c %c %lf %c\n",x,y);
	if(a!=soma){
		printf("Diferente\n");
	} else {
		printf("igual\n");
	}
	while(x<5){
		//printf("Digite um valor ou -1 para sair\n");
		//scanf("%lf",&y);
		//if(y!=-1)
		//	soma += y;
		//else
		//	break;
		printf("%d\n", x);
		//usleep(1000000);
		x++;
	}
	printf("Valor  final de x %d %.2lf\n",x, soma);
	double media = soma/x;
	printf("\n%lf\n",media);
}
