#include <stdio.h>
#include <stdlib.h>
using namespace std;
int main(){
    int x=0;
    while(x<10){
        printf("Passou aqui %d\n",x++);
    }
}
